package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class sample1 
{
	@Test
	public void TC1()
	{

		System.setProperty("webdriver.gecko.driver","C:\\Users\\vijay\\selenium\\geckodriver-v0.30.0-win32\\geckodriver.exe" );
	
		WebDriver driver=new FirefoxDriver();
		
		driver.get("https://www.flipkart.com/");
	}
}
