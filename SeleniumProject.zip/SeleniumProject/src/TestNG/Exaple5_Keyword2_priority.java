package TestNG;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Exaple5_Keyword2_priority 
{

	@Test(priority=2)
	public void TC1()
	{
		Reporter.log("TC1 runnimg..",true);
	}

	@Test(priority=1)
	public void TC2()
	{
		Reporter.log("TC2 runnimg..",true);
	}
}
