package TestNG;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class example3_generate_EmailableReport
{


	@Test
	public void m1()
	{
		System.out.println("runnig method m1");
		//Reporter.log("runnig method m1",true);
	}


	@Test
	public void m2()
	{
		System.out.println("runnig method m2");
		//Reporter.log("runnig method m2");
		//Assert.fail();
	}
	

}
