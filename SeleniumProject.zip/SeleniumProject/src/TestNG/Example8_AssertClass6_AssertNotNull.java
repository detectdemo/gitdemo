package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Example8_AssertClass6_AssertNotNull
{


	@Test
	public void AssertNull()
	{
		String str="abcd";
		//String str=null;
		Assert.assertNotNull(str,"null contain");
	}
}
