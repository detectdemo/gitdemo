package TestNG;

import java.security.PrivateKey;
import java.util.concurrent.PriorityBlockingQueue;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Example5_Keyword_priority2 
{

	@Test(priority=2)
	public void TC1()
	{
		Reporter.log("TC1 runnimg..",true);
	}

	@Test(priority=1)
	public void TC2()
	{
		Reporter.log("TC2 runnimg..",true);
	}
	@Test            //by default=0
	public void TC4()
	{
		Reporter.log("TC4 running..",true);
	}
	@Test            //by default=0
	public void TC3()
	{
		Reporter.log("TC3 running..",true);
	}
	
	
}
