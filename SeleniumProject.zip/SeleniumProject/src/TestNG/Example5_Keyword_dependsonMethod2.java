package TestNG;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Example5_Keyword_dependsonMethod2
{


	@Test            
	public void login1()
	{
		Reporter.log("login1 running..",true);
	}
	@Test            
	public void login2()
	{
		//Assert.fail();
		Reporter.log("login2 running..",true);
	}
	
		@Test(dependsOnMethods= {"login1","login2"})            
		public void logout()
		{
			Reporter.log("logout running..",true);
		}
		
}
