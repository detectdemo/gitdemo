package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Example8_AssertClass5_AssertNull 
{



	@Test
	public void AssertNull()
	{
	//	String str="abcd";
		String str=null;
		Assert.assertNull(str);
	}
}
