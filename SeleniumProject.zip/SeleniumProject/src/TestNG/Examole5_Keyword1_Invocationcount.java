package TestNG;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Examole5_Keyword1_Invocationcount
{

	@Test(invocationCount = 5)
	public void TC1()
	{
		Reporter.log("running TC1..",true);
	}
}
