package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Example7_AssertClass1_Assertequals
{

	@Test
	public void TC1()
	{
		String actual="Hi";
		String expected="hi";
		Assert.assertEquals(actual, expected,"Fail actual& Expected result Diff");
	}
}
