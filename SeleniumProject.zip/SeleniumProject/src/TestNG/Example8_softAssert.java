package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Example8_softAssert
{


	@Test
	public void Assert()
	{
		SoftAssert soft=new SoftAssert();
		
		String str1="Hi";
		String str2="hi";
		String str3="Hello";
		
		soft.assertEquals(str1, str2,"Faild1: both result are diff");
		
		soft.assertEquals(str2, str3, "Failed: both result are diff");
		
		soft.assertAll();
	}
}
