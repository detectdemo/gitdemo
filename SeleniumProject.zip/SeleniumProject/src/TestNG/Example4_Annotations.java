package TestNG;

import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Example4_Annotations
{

	@BeforeClass
	public void openBrowser()
	{
		Reporter.log("Open Browser.",true);
	}
    @BeforeMethod
	public void loginToapp()
	{
		Reporter.log("logine to app                                                                                                                                                                                                                            ..",true);
	}
    @Test
    public void TC2()
	{
		Reporter.log("runnig TC2..",true);
	}
	
	@Test
	public void TC1()
	{
		Reporter.log("runnig TC1..",true);
	}
	@AfterMethod
	public void logoutToapp()
	{
		Reporter.log("logout to app..",true);
	}
	
	@AfterClass
	public void CloseBrowser()
	{
		Reporter.log("Close Browser.",true);
	}
}
