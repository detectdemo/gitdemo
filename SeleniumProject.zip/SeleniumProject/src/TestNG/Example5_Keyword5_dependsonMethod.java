package TestNG;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Example5_Keyword5_dependsonMethod
{


	
	@Test            
	public void logine() throws InterruptedException
	{
		Assert.fail();
		Reporter.log("logine running Test Case..",true);
	}
	@Test(dependsOnMethods= {"logine"})            
	public void logout()
	{
		Reporter.log("logout running Test Case..",true);
	}
}
