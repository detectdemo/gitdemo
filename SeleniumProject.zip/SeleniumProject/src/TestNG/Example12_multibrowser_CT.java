package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;

public class Example12_multibrowser_CT
{

	@Parameters("browserName")
	@Test
	public void TC1(String browserName)
	{
		WebDriver driver=null;
		if(browserName.equals("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe");
	
		 driver=new ChromeDriver();
		}
	
		else if(browserName.equals("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver","C:\\Users\\vijay\\selenium\\geckodriver-v0.30.0-win32\\geckodriver.exe" );
		
			 driver=new FirefoxDriver();
			
			
		}
		
		else if (browserName.equals("opera"))
		{
			System.setProperty("webdriver.opera.driver", "");
		     driver=new OperaDriver();
		}
	
		 driver.get("https://kite.zerodha.com/");
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			//enter UN
			driver.findElement(By.xpath("//input[@type=\"text\"]")).sendKeys("DV1510");
			//enter psw
			driver.findElement(By.xpath("//input[@type=\"password\"]")).sendKeys("Pass@123");
		
			//click
			
			driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();

			//enter pin
			driver.findElement(By.xpath("//input[@placeholder=\"PIN\"]")).sendKeys("959594");;
	       
			//clickcontbtn
			
			driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();

			//verifyUID
			String act = driver.findElement(By.xpath("//span[@class=\"user-id\"]")).getText();
			
		
			String exp="DV1510";
			
			if(act.equals(exp))
			{
		
				System.out.println("pass");
			}
			else
			{
				System.out.println("fail");
			}

	
	
	}
}
