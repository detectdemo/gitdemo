package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Example8_AssertClass3_AssertTrue 
{


	@Test
	public void AssertEquals()
	{
		boolean ACtResult = true;
		Assert.assertTrue(ACtResult,"false");
	}
}
