package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Example8_AssertClass7
{


	@Test
	public void AssertNull()
	{
		String str1="Hi";
		String str2="hi";
		String str3="Hello";
		
		Assert.assertEquals(str1, str2,"Faild1: both result are diff");
		
		Assert.assertEquals(str2, str3, "Failed: both result are diff");
		
	}
}
