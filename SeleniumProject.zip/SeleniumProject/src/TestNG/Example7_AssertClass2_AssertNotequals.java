package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Example7_AssertClass2_AssertNotequals
{


	@Test
	public void TC1()
	{
		String actual="Hi";
		String expected="Hi";
		Assert.assertNotEquals(actual, expected,"Fail actual& Expected result same");
	}
}
