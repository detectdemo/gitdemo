package TestNG;

import org.testng.annotations.Test;

public class example4 
{


	@Test
	public void m1()
	{
		System.out.println("runnig method m1");
		//Reporter.log("runnig method m1",true);
	}


	@Test
	public void m2()
	{
		System.out.println("runnig method m2");
		//Reporter.log("runnig method m2");
		//Assert.fail();
	}
}
