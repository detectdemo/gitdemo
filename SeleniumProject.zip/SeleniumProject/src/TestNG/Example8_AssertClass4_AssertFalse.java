package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Example8_AssertClass4_AssertFalse 
{



	@Test
	public void AssertEquals()
	{
		boolean ACtResult = false;
		Assert.assertFalse(ACtResult,"is diff");
	}
}
