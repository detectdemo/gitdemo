package TestNG;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Example6_TestSuit_sample3
{


	@Test
	public void TC5()
	{
		Reporter.log("running TC5..",true);
	}
	
	@Test
	public void TC6()
	{
		Reporter.log("running TC6..",true);
	}
}
