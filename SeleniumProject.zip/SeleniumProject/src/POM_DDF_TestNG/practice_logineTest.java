package POM_DDF_TestNG;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class practice_logineTest
{

	kitelogin1page login1;
	kitelogin2page login2;
	 kiteHomepage Home;
	 WebDriver driver;
	 Sheet sh ;
	@BeforeClass
	public void openBrowser() throws EncryptedDocumentException, IOException
	{
		FileInputStream file=new FileInputStream("C:\\Users\\vijay\\selenium\\July21B.xlsx");
		 sh = WorkbookFactory.create(file).getSheet("DDF");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		 driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("https://kite.zerodha.com/");
		  login1=new kitelogin1page(driver);
		 login2=new kitelogin2page(driver);
		 Home=new kiteHomepage(driver);
		 
		
	}
	@BeforeMethod
	public void login()
	{
		login1.inpkitelogin1pageUsername(sh.getRow(0).getCell(0).getStringCellValue());
		login1.inpkitelogin1pagePassword(sh.getRow(0).getCell(1).getStringCellValue());
		login1.inpkitelogin1pageLoginBtn();
		login2.inpkitelogin2pagePin(sh.getRow(0).getCell(2).getStringCellValue());
		login2.inpkitelogin2pageCntBtn();
		
	}
	@Test
	public void verifyID()
	{

		String act = Home.getkiteHomepageUserId();
		String exp=sh.getRow(0).getCell(3).getStringCellValue();
		Assert.assertEquals(act, exp,"Failed both resultare diff");
	}
	@AfterMethod
	public void logout()
	{
		Home.clikonHomepageBtn();
		Home.clickonlogoutBtn();
		
	}
	public void closeBrowser() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.close();
		
	}
}
