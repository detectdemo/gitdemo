package POM_DDF_TestNG;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class KiteLoginTestT 
{

	//int a;
	kitelogin1page login1;
	kitelogin2page login2;
	kiteHomepage Home ;
	Sheet sh;
	WebDriver driver;
	
	@BeforeClass
	public void openBrowser() throws EncryptedDocumentException, IOException
	{
		

		FileInputStream file=new FileInputStream("C:\\Users\\vijay\\selenium\\July21B.xlsx");
		 sh = WorkbookFactory.create(file).getSheet("DDF");
System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		 driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("https://kite.zerodha.com/");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//a=10;
	     login1=new kitelogin1page(driver);
		 login2=new kitelogin2page(driver);
		 Home=new kiteHomepage(driver);
		
		
	}
	@BeforeMethod
	public void LogineToApp()
	{
		login1.inpkitelogin1pageUsername(sh.getRow(0).getCell(0).getStringCellValue());
		login1.inpkitelogin1pagePassword(sh.getRow(0).getCell(1).getStringCellValue());
		login1.inpkitelogin1pageLoginBtn();

		login2.inpkitelogin2pagePin(sh.getRow(0).getCell(2).getStringCellValue());
		login2.inpkitelogin2pageCntBtn();
	}

	@Test
	public void verifyUserID()
	{
		String actResult = Home.getkiteHomepageUserId();
		String ExpResult="abcd";//sh.getRow(0).getCell(3).getStringCellValue();
		Assert.assertEquals(actResult, ExpResult,"Failed:both result are diff");
	
		//Home.verifykitehomepageID(sh.getRow(0).getCell(3).getStringCellValue());
	}
	

	@AfterMethod
	public void LogoutFromApp()
	{
	
		Home.clikonHomepageBtn();
		Home.clickonlogoutBtn();
		
	}
	

	@AfterClass
	public void CloseBrowser() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.close();
		driver=null;
		sh=null;
		login1=null;
		login2=null;
		Home=null;
	
	}
}
