package POM_DDF_TestNG;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class kiteloginTest 
{
  
	public static void main(String[] args) throws InterruptedException, EncryptedDocumentException, IOException {
		
		FileInputStream file=new FileInputStream("C:\\Users\\vijay\\selenium\\July21B.xlsx");
		Sheet sh = WorkbookFactory.create(file).getSheet("DDF");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("https://kite.zerodha.com/");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		kitelogin1page login1=new kitelogin1page(driver);

		String UNInfo = sh.getRow(0).getCell(0).getStringCellValue();
		login1.inpkitelogin1pageUsername(UNInfo);
		
		String PSWinfo = sh.getRow(0).getCell(1).getStringCellValue();
		login1.inpkitelogin1pagePassword(PSWinfo);
	    login1.inpkitelogin1pageLoginBtn();
		
		kitelogin2page login2=new kitelogin2page(driver);
		String PINinfo = sh.getRow(0).getCell(2).getStringCellValue();
		login2.inpkitelogin2pagePin(PINinfo);
		login2.inpkitelogin2pageCntBtn();
		
		kiteHomepage Home=new kiteHomepage(driver);
		String expuserId = sh.getRow(0).getCell(3).getStringCellValue();
		Home.verifykiteHomepageUserId(expuserId);
		
		Thread.sleep(2000);
		driver.close();
		
		
	}
}
