package POM_DDF_TestNG_BaseClass_UtilityClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class KiteLoginTestT extends BaseClass
{

	
//	WebDriver driver; //global veriable
//	public void initializBrowser()
//	{
//		System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
//		 driver=new ChromeDriver();
//		driver.manage().window().maximize();
//		 driver.get("https://kite.zerodha.com/");
		
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//	}
	//int a;
	kitelogin1page login1;
	kitelogin2page login2;
	kiteHomepage Home ;
	int TestCaseID ;
	
	
	@BeforeClass
	public void openBrowser() throws EncryptedDocumentException, IOException
	{
		


		 initializBrowser();
		//a=10;
	     login1=new kitelogin1page(driver);
		 login2=new kitelogin2page(driver);
		 Home=new kiteHomepage(driver);
		
	}
	@BeforeMethod
	public void LogineToApp() throws EncryptedDocumentException, IOException
	{
		login1.inpkitelogin1pageUsername(UtilityClass.getDataFromPF("UN"));
		login1.inpkitelogin1pagePassword(UtilityClass.getDataFromPF("PSW"));
		login1.inpkitelogin1pageLoginBtn();

		login2.inpkitelogin2pagePin(UtilityClass.getDataFromPF("PIN"));
		login2.inpkitelogin2pageCntBtn();
	}

	@Test
	public void verifyUserID() throws EncryptedDocumentException, IOException
	{ 
		TestCaseID = 200;
		String actResult = Home.getkiteHomepageUserId();
		String ExpResult=UtilityClass.getDataFromPF("UN");
		Assert.assertEquals(actResult, ExpResult,"Failed:both result are diff");
	
		//Home.verifykitehomepageID(sh.getRow(0).getCell(3).getStringCellValue());
	}
	

	@AfterMethod
	public void LogoutFromApp(ITestResult result) throws IOException
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			UtilityClass.CaptureScreenShot(driver, TestCaseID);
		}
	
		Home.clikonHomepageBtn();
		Home.clickonlogoutBtn();
		
	}
	

	@AfterClass
	public void CloseBrowser() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.close();
		driver=null;
		login1=null;
		login2=null;
		Home=null;
	
	}
}
