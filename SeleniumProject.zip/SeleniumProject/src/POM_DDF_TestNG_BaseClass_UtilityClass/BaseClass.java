package POM_DDF_TestNG_BaseClass_UtilityClass;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass
{

	WebDriver driver;
	public void initializBrowser() throws IOException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		 driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get(UtilityClass.getDataFromPF("URL"));
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
}
