package POM_DDF_TestNG_BaseClass_UtilityClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class kiteHomepage
{
//step1:declaration
	@FindBy(xpath="//span[@class=\"user-id\"]") private WebElement userID;
	@FindBy(xpath="//a[text()=\" Logout\"]") private WebElement logoutBtn;
	//step2:initilazation
	
	public kiteHomepage(WebDriver driver)
	{
		PageFactory.initElements(driver , this);
	}
	
	
	public String getkiteHomepageUserId()
	{
		String userIDvalue = userID.getText();
		return userIDvalue ;
	}
	
	public void clikonHomepageBtn()
	{
		userID.click();
	}
	
	public void clickonlogoutBtn()
	{
	logoutBtn.click();	
	}
	
	
	//Step3: usages
	
//	public void verifykiteHomepageUserId(String expUserId)
//	{
//		String actuserid = userID.getText();
	//	String ecpuserID="expUserId";
		
//		if(actuserid.equals(expUserId))
//		{
//			System.out.println("pass");
//		}
//		else
//		{
//			System.out.println("fail");
//		}
		
//	}
	
	
	
	
}
