package POM_DDF_TestNG_BaseClass_UtilityClass;

public class demo_returntype
{
	public static void main(String[] args) {
	int num1=5;
    int num2=addition(10,20);
		
		System.out.println(num1*num2);
		
	}
	public static int addition (int a,int b)
	{
		int sum=a+b;
		return sum;
	}
		
		
	

}
