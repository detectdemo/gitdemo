package page_object_module;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class kiteHomepage
{
//step1:declaration
	@FindBy(xpath="//span[@class=\"user-id\"]") private WebElement userID;
	
	//step2:initilazation
	
	public kiteHomepage(WebDriver driver)
	{
		PageFactory.initElements(driver , this);
	}
	
	//Step3: usages
	
	public void varifyuserid()
	{
		String actuserid = userID.getText();
		String ecpuserID="DV1510";
		
		if(actuserid.equals(ecpuserID))
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}
		
	}
	
	
	
	
}
