package page_object_module;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class kiteloginTest 
{

	public static void main(String[] args) throws InterruptedException {
		
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("https://kite.zerodha.com/");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		kitelogin1page login1=new kitelogin1page(driver);

		login1.enterusername();
		login1.enterpsw();
		login1.clickbtn();

		kitelogin2page login2=new kitelogin2page(driver);
		
		login2.enterpin();
		login2.clickbtn();
		
		kiteHomepage login3=new kiteHomepage(driver);
		 login3.varifyuserid();
		
		
		
		
	}
}
