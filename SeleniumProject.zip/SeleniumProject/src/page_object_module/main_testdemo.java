package page_object_module;
//main class
public class main_testdemo 
{

	public static void main(String[] args)
	{
		
		TestDemo d1=new TestDemo(10,20);
		
		d1.addition();
		
		System.out.println();
		
		
		
		
		
		
		
		
	}
}
