package page_object_module;
//regular class
public class TestDemo 
{
    //step1:declaration :global veriable
	int num1;
	int num2;
	//step2: initilazation
	public TestDemo(int a,int b)
	{
		num1=a;
		num2=b;
	}
	
	
	

	public void addition()
	{
		System.out.println(num1+num2);
	}
	
	
	
}
