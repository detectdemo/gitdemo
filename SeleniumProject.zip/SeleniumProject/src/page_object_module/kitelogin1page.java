package page_object_module;

import java.security.PrivateKey;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class kitelogin1page 
{
		 //step1:declaration
	   @FindBy(xpath="//input[@type=\"text\"]")  private WebElement UN;//private WebElement UN-drivar.findElemenet(By.xpath(""));
	   @FindBy(xpath="//input[@type=\"password\"]")  private WebElement PSW;
	   @FindBy(xpath="//button[@type=\"submit\"]") private WebElement LoginBtn;
		 
	    //step2:initilazation
		 kitelogin1page(WebDriver driver)
		 {
			 PageFactory.initElements(driver, this);
		 }
		 
		 
		 //step3:usages
		 
		 public void enterusername()
		 {
			 UN.sendKeys("DV1510");
		 }
		 
		 public void enterpsw()
		 {
			 PSW.sendKeys("Pass@123");
		 }
		 
		 
		 public void clickbtn()
		 {
			 LoginBtn.click();
		 }
	 
}
