package javascript;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class example 
{

	public static void main(String[] args) {
		
System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("https:google.com");
		
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 driver.manage().window().maximize();
		 driver.get("https://www.browserstack.com/users/sign_in");
		 js.executeScript("document.getElementByxpath('UN').value='DV1510';");
		 js.executeScript("document.getElementById('user_password').value='password';");
		 js.executeScript("document.getElementById('user_submit').click();");
		 js.executeScript("alert('enter correct login credentials to continue');");
		
		
		
		
		
	}
}
