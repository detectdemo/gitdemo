package DDF;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.chrome.ChromeDriver;

public class Example1_without_DDF
{

	public static void main(String[] args) {
		
System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("https://kite.zerodha.com/");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//enter UN
		driver.findElement(By.xpath("//input[@type=\"text\"]")).sendKeys("DV1510");
		//enter psw
		driver.findElement(By.xpath("//input[@type=\"password\"]")).sendKeys("Pass@123");
	
		//click
		
		driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();

		//enter pin
		driver.findElement(By.xpath("//input[@placeholder=\"PIN\"]")).sendKeys("959594");;
       
		//clickcontbtn
		
		driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();

		//verifyUID
		String act = driver.findElement(By.xpath("//span[@class=\"user-id\"]")).getText();
		
	
		String exp="DV1510";
		
		if(act.equals(exp))
		{
	
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}

		
		
		
		
	}
}
