import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class kite
{

	public static void main(String[] args) throws InterruptedException {
		
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		Thread.sleep(2000);
		driver.get("https://www.amazon.in/");
		
		driver.findElement(By.xpath("//input[@name=\"field-keywords\"]")).sendKeys("laptops");
		driver.findElement(By.xpath("//input[@type=\"submit\"]")).click();
		
		driver.findElement(By.xpath("(//img[@class=\"_dGV0c_image_1pfbQ\"])[3]")).click();

		driver.findElement(By.xpath("//input[@title=\"Add to Shopping Cart\"]")).click();
		Thread.sleep(4000); 
		String text = driver.findElement(By.xpath("(//div[@class=\"a-box-inner\"])[9]")).getText();
		System.out.println(text);
		Thread.sleep(2000);

		//driver.findElement(By.xpath("//input[@type="submit"]")).click();
		
		//driver.findElement(By.xpath("//span[text()=\"GR9861\"]")).getText();
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
