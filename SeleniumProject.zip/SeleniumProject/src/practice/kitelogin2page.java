package practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class kitelogin2page 
{

	
	@FindBy(xpath="//input[@placeholder=\\\"PIN\\\"]") private WebElement PIN;
	@FindBy(xpath="//button[text()=\\\"Continue \\\"]") private WebElement ConBtn;
	
	
		
	
	public kitelogin2page(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public void enterpin()
	{
		PIN.sendKeys("959594");
	}
	public void clickBtn()
	{
		ConBtn.click();
	}
	
	
	
	
	
	
	
}
