package practice;

import java.util.Arrays;
import java.util.Scanner;

public class demo5 
{

	public static void main(String[] args) {

		
		int str=1;
	
		for(int i=1;i<=str;i++)
		{
			for(int j=1;j<=4;j++)
			{
				System.out.print(" * ");
			}
			System.out.println();
			str++;
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
}
