package practice;

import java.awt.Desktop.Action;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Example 
{

	public static void main(String[] args) throws InterruptedException
	{
	
System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("https://www.marathishaadi.com");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//button[text()=\"Let's Begin\"]")).click();
	    driver.findElement(By.xpath("//input[@type=\"email\"]")).sendKeys("cd802191@gmail.com");
       driver.findElement(By.xpath("//input[@type=\"password\"]")).sendKeys("cd802191@123");
		 Thread.sleep(2000);
		driver.findElement(By.xpath("//div[text()=\"Select\"]")).click();
         driver.findElement(By.xpath("//div[text()=\"Self\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[text()=\" Male\"]")).click();
		driver.findElement(By.xpath("(//button[text()=\"Next\"])[2]")).click();
		driver.findElement(By.xpath("//input[@name=\"first_name\"]")).sendKeys("Rahul");
		 driver.findElement(By.xpath("//input[@name=\"last_name\"]")).sendKeys("joshi");
		  driver.findElement(By.xpath("//div[text()=\"Day\"]")).click();
		 driver.findElement(By.xpath("//div[text()=\"04\"]")).click();
		WebElement Month= driver.findElement(By.xpath("//div[text()=\"Month\"]"));
		Month.click();
		 driver.findElement(By.xpath("//div[text()=\"Feb\"]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[text()=\"Year\"]")).click();
		driver.findElement(By.xpath("//div[text()=\"1992\"]")).click();
        driver.findElement(By.xpath("//div[text()=\"Select\"]")).click();
		 driver.findElement(By.xpath("//div[text()=\"Hindu\"]")).click();
      WebElement community = driver.findElement(By.xpath("(//div[@class=\"Dropdown-root false\"])[5]"));		
      community.click();
     String text = community.getText();
		System.out.println("community:"+text);
		 Thread.sleep(2000);
         driver.findElement(By.xpath("//button[text()=\"Sign up\"]")).click();
		Actions Act=new Actions(driver);
		 WebElement place = driver.findElement(By.xpath("//input[@id=\"places\"]"));
		 place.sendKeys("mumbai");
		 Thread.sleep(2000);
		 Act.moveToElement(place);
         Act.sendKeys(Keys.ARROW_DOWN).perform();
         Act.sendKeys(Keys.ENTER).perform();
	    driver.findElement(By.xpath("//div[text()=\"Yes\"]")).click();
		 driver.findElement(By.xpath("//div[text()=\"Veg\"]")).click();
		 driver.findElement(By.xpath("//input[@id=\"height\"]")).click();
     	Act.sendKeys(Keys.ARROW_DOWN).perform();
     	Act.sendKeys(Keys.ENTER).perform();
	   Thread.sleep(2000);
         WebElement c = driver.findElement(By.xpath("//input[@id=\"caste\"]"));
		c.click();
		c.sendKeys("96 Kuli Maratha");
		 Act.moveToElement(c);
         Act.sendKeys(Keys.ARROW_DOWN).perform();
       	Act.sendKeys(Keys.ENTER).perform();
	    driver.findElement(By.xpath("//input[@id=\"casteNoBar\"]")).click();
        driver.findElement(By.xpath("//span[text()=\"Continue\"]")).click();
       WebElement Ed = driver.findElement(By.xpath("//input[@name=\"educationLevel\"]"));
        Ed.click();
       Thread.sleep(2000);
       Ed.sendKeys("B");
       Thread.sleep(2000);
       Act.moveToElement(Ed);
       Act.sendKeys(Keys.ARROW_DOWN).perform();
       Act.sendKeys(Keys.ARROW_DOWN).perform();
     	Act.sendKeys(Keys.ENTER).perform();
        WebElement work = driver.findElement(By.xpath("//input[@id=\"workingWith\"]"));
        work.click();
        Thread.sleep(2000);
        Act.moveToElement(work);
        Act.sendKeys(Keys.ARROW_DOWN).perform();
      	Act.sendKeys(Keys.ENTER).perform();
        WebElement as = driver.findElement(By.xpath("//input[@name=\"workingAs\"]"));
        as.click();
        Thread.sleep(2000);
        Act.moveToElement(as);
        Act.sendKeys(Keys.ARROW_DOWN).perform();
      	Act.sendKeys(Keys.ENTER).perform();
        WebElement comname = driver.findElement(By.xpath("//input[@name=\"employer\"]"));
        comname.click();
        Thread.sleep(2000);
        Act.moveToElement(comname);
        Act.sendKeys(Keys.ARROW_DOWN).perform();
        Act.sendKeys(Keys.ARROW_DOWN).perform();
        Act.sendKeys(Keys.ENTER).perform();
        WebElement income = driver.findElement(By.xpath("//input[@name=\"income\"]"));
        income.click();
        Thread.sleep(2000);
        Act.moveToElement(income);
        Act.sendKeys(Keys.ARROW_DOWN).perform();
        Act.sendKeys(Keys.ARROW_DOWN).perform();
        Act.sendKeys(Keys.ENTER).perform();
		driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
		driver.findElement(By.xpath("//input[@id=\"mobileNumber\"]")).sendKeys("9999999999");
		WebElement country = driver.findElement(By.xpath("//input[@name=\"countryCode\"]"));
		country.click();
		Thread.sleep(2000);
		country.clear();
		country.sendKeys("+91");
		Thread.sleep(2000);
        Act.moveToElement(country);
        Act.sendKeys(Keys.ARROW_DOWN).perform();
        Act.sendKeys(Keys.ENTER).perform();
		driver.findElement(By.xpath("//span[text()=\"Create Profile\"]")).click();
		driver.get("https://www.marathishaadi.com/registration/user?btn=2");
		driver.findElement(By.xpath("//div[@class=\"reg_layer_close\"]")).click();
		WebElement Mt = driver.findElement(By.xpath("(//span[text()=\"Marathi\"])[1]"));
		System.out.println("mother tongue :"+Mt.getText());

		


		
		


        

       

     



		 
		
		 


		 





		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
