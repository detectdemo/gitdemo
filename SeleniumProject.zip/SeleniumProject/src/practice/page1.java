package practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class page1

{
@FindBy(xpath="//input[@type=\"text\"]")private WebElement UN;
@FindBy(xpath="//input[@type=\"password\"]")private WebElement PSW;
@FindBy(xpath="//button[@type=\"submit\"]")private WebElement CntBtn;

     public page1(WebDriver Driver) 
  {

    	PageFactory.initElements(Driver, this);
  }
     public void inppage1UN()
     {
    	 UN.sendKeys("DV1510");
     }
     
     public void inppage1PSW()
     {
    	 PSW.sendKeys("Pass@123");
     }
     public void inppage1CntBtn()
     {
    	 CntBtn.click();
     }
     



}
