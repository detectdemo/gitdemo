package practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class page2
{

	@FindBy(xpath="//input[@placeholder=\"PIN\"]")private WebElement PIN;
	@FindBy(xpath="//button[text()=\"Continue \"]")private WebElement clickCOntBtn;
	
	
	public page2(WebDriver Driver) 
	{
		PageFactory.initElements(Driver, this);
	}
	 public void inppage2PIN()
     {
    	 PIN.sendKeys("959594");
     }
	 public void inppage2ContBtn()
     {
    	 clickCOntBtn.click();
     }
     
     
}
