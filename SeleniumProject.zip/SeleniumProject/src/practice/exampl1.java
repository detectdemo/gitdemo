package practice;

public class exampl1 {

}
