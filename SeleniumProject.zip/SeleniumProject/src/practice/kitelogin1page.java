package practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class kitelogin1page 
{
//step1: declaration
	  @FindBy(xpath="//input[@type=\\\"text\\\"]")  private WebElement UN;
     @FindBy(xpath="//input[@type=\\\"password\\\"]") private WebElement 	PSW;
     @FindBy(xpath="//button[@type=\\\"submit\\\"]") private WebElement LoginBtn;
	
	
	//step2: initilazation
	public kitelogin1page(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	
	public void enterUN()
	{
		UN.sendKeys("DV1510");
	}
	public void enterPSW()
	{
		PSW.sendKeys("Pass@123");
	}
	
	public void clickbtn()
	{
		LoginBtn.click();
	}
	
	
}
