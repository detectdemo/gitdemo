package practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class page3 
{

	@FindBy(xpath="//span[@class=\"user-id\"]")private WebElement verifyUID;
	
	public page3(WebDriver Driver) {
	
		PageFactory.initElements(Driver,this);
	}
	public void inppage3verifyUID()
	{
String t = verifyUID.getText();
String exp="DV1510";
if(t.equals(exp)) {
	System.out.println("pass");
	
}
else
{
	System.out.println("fail");
}
	}
}
