package practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class kiteHomepage 
{

	
@FindBy(xpath="//span[@class=\\\"user-id\\\"]")private	WebElement UID;
	
	
	public kiteHomepage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public void varifyUID()
	{
		String acttext = UID.getText();
		String exptext="DV1510";
		
		if(acttext.equals(exptext))
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}
	}
	
	
	
	
	
	
}
