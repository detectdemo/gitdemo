package practice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class page_Test
{

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("https://kite.zerodha.com/");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		page1 log1=new page1(driver);
		log1.inppage1UN();
		log1.inppage1PSW();
		log1.inppage1CntBtn();
		
		page2 log2=new page2(driver);
		log2.inppage2PIN();
		log2.inppage2ContBtn();
		
		page3 log3=new page3(driver);
		
		log3.inppage3verifyUID();
		
		
		
		
		
		
		
		
		
	}
}
