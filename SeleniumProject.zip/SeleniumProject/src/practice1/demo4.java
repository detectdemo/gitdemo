package practice1;

import java.util.Scanner;

public class demo4 {
	
	public static void main(String[] args) {
	
		int or=32153;
		

		String num = Integer.toString(or);
		
		String num1="";
		
		
		for(int i=0;i<=num.length()-1;i++)
		{
			num1=num1+num.charAt(i);
		}
		
		int print=Integer.parseInt(num1);
		System.out.println(print);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
