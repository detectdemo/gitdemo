package practice1;

import java.util.Scanner;

public class demo3
{

	
	public static void main(String[] args) {
		
		int num=12345;
		
		String num1=Integer.toString(num);
		String rev="";
		
		for(int i=0;i<=num1.length()-1;i++)
		{
			rev=rev+num1.charAt(i);
			
		}
		int rev1=Integer.parseInt(rev);
		
		System.out.println(rev1);
		
}
}