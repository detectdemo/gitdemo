package Logical_program;

public class Exampl4_Reverse_string1
{

	public static void main(String[] args) {
		
		
		String org ="ab  cd ";
		String rev = " ";
		
		String[] s1= org.split("");  //[ab(0) cd(1)]==2
		
		for(int i=0; i<=s1.length-1;i++)
		{
			String str1 = s1[i];      //ab
			String str2 = reversString(str1);  //ba
			System.out.print(str2 + "");
		}
		
		
		
	}
	
	
	public static String reversString(String org)
	{
		String rev="";
		for(int i=org.length()-1;i>=0;i--)
		{
			rev=rev +org.charAt(i);
		}
		return rev ;

		
	}
}
