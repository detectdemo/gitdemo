package Logical_program;

public class Exampl5_pallindrome 
{

	public static void main(String[] args) {
		
		
		String org="madam";
		String rev="";
		
		for(int i=org.length()-1;i>=0;i--)
		{
			rev=rev+org.charAt(i);
		}
		
		System.out.println("string org:"+ org);
		System.out.println("string rev:"+ rev);
		
		
		if(org.equals(rev))
		{
			System.out.println("given string is pallindrome");
		}
		else
		{
			System.out.println("given string is not pallindrome");
		}
		
		
		
		
		
	}
}
