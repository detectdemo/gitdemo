package Logical_program;

public class Example12_IMP_Reverse_order_Without_string_funcation
{

	public static void main(String[] args) {
		
		int num =12345;
		int revnum =0;
		
		for(int i=num; i>0; i=i/10)
		{
			int rem= i%10;                 
			
			
			revnum= revnum *10+rem;    // 54=54321
			
		}
		
		
		System.out.println(revnum);
		
		
		
		
		
		
		
		
		
	}
}
