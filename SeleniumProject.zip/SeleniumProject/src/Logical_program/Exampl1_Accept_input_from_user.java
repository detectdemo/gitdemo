package Logical_program;

import java.util.Scanner;

public class Exampl1_Accept_input_from_user
{

	public static void main(String[] args) {
		
		
		Scanner scan =new Scanner(System.in);
		
		
		System.out.println("enter Number1: ");
		
		int num1= scan.nextInt();    //accept int input
		System.out.println("enter NUmber2:");
		
		int num2 = scan.nextInt();
		
		System.out.println(num1+num2);
		
		
		System.out.println("enter student Name:");
		
		String Name = scan.next();  //accept String input from user
		
		System.out.println("student Name:"+Name);
		
		
		
		
		
		
		
		
		
	}
}
