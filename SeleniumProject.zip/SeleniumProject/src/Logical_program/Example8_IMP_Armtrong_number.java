 package Logical_program;

import java.util.Arrays;

public class Example8_IMP_Armtrong_number 
{

	public static void main(String[] args) {
		

		int [] ar= {12,4345,56,4,65};
		
		Arrays.sort(ar);
		
		for(int i=0;i<=ar.length-1;i++)
		{
			System.out.println(ar[i]);
		}
		
		
		
		
		
		
	}
}
