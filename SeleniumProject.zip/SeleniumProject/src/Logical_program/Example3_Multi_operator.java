package Logical_program;

public class Example3_Multi_operator
{

	public static void main(String[] args) {
		
		int num1=10;
		int num2=20;
		
		
		int sum=0; //10
		
		for(int i=1; i<=num2; i++)
		{
			sum= sum+num1;  //0+10=10+10=20+10=30+10=40
		}
		
		
		System.out.println(sum);  //10
		
		
		
		
		
		
		
		
	}
}
