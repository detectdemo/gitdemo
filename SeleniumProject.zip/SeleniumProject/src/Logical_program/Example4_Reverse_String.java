package Logical_program;

public class Example4_Reverse_String 
{

	public static void main(String[] args) {
		
		 String org="abcd";
		 String rev="";
		 
		 
		                    //-1>=0 //-1
		 for (int i=org.length()-1;i>=0;i--)
			// for(int i=0;i<=org.length()-1;i++)
		 {
			 rev=rev+org.charAt(i);  //dcb + a =dcba  //0+a=a+b=ab+c=abc
		 }
		 System.out.println("string org:"+org);
		 System.out.println("string rev:"+rev);
		 
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
