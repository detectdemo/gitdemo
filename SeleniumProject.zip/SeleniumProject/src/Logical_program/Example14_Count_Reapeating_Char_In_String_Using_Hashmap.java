package Logical_program;

import java.util.HashMap;
import java.util.Set;

public class Example14_Count_Reapeating_Char_In_String_Using_Hashmap
{

	String str = "abcabcaaad";

	HashMap<Character, Integer> mp = new HashMap<Character, Integer>();
					
	for (int i = 0; i <= str.length() - 1; i++) 
	{							//0
		char charValue = str.charAt(i);   //a
		
		if (mp.containsKey(charValue))   //a--> true
		{
			mp.put(charValue, mp.get(charValue) + 1);
		} 
		else
		{
			mp.put(charValue, 1);
		}
                                      
	}
	
	
	Set<Character> keys = mp.keySet(); //[a, b, c, d]
	
	//print only duplicate element
	for (Character key : keys) 
	{
		if(mp.get(key)>1) 
		{
			System.out.println(key +": "+ mp.get(key));
		}
	}
	
	//System.out.println("a: "+ mp.get('a'));
	
}
}
