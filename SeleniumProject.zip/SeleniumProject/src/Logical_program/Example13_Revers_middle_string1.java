package Logical_program;

public class Example13_Revers_middle_string1 
{

	public static void main(String[] args) 
	{
		String str = "abc xyz abc1 xyz1"; 

		String[] ar = str.split(" "); //[abc(0) xyz(1) abc1(2) xyz1(3)]

						//4<=3				4
		for (int i = 0; i <= ar.length - 1; i++) 
		{
				//3%2 = 1
			if (i % 2 == 0)
			{				//ar[2]
				String s1 = ar[i];  //abc1
				ar[i] = reverseString(s1);   //re initialization of string info for even index			
			}

		}
		
		for (int i = 0; i <= ar.length-1; i++)
		{
			System.out.print(ar[i]+" ");
		}
		
	}

	public static String reverseString(String inp) {
		String rev = "";
		for (int i = inp.length() - 1; i >= 0; i--) {
			rev = rev + inp.charAt(i);
		}
		return rev;
	}


}
