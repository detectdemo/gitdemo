package Logical_program;

import java.util.Arrays;

public class Example2_copmpare_multidime_array 
{

	public static void main(String[] args) {
		
		
		
		int[][] ar={{10,20,30,},{40,50,60},{70,80,90}};
		
		int[][] ar1={{10,20,30,},{40,50,60},{70,80,90}};
		int[][] ar2={{10,20,20,},{40,50,60},{70,80,90}};

		
		for(int i=0;i<=2;i++)
		{
			for(int j=0;j<=2;j++)
			{
				System.out.print(ar[i][j]+" ");
			}
			
			System.out.println();
		}
		
		
		

		for(int i=0;i<=2;i++)
		{
			for(int j=0;j<=2;j++)
			{
				System.out.print(ar1[i][j]+" ");
			}
			
			System.out.println();
		}
		
		System.out.println(Arrays.deepEquals(ar,ar1));
		
		
		
		System.out.println(Arrays.deepEquals(ar,ar1));

		
	}
}
