package Logical_program;

import java.util.Arrays;

public class Examole2_compare2_interger_Arrays 
{

	public static void main(String[] args) {
		
		int ar1[]= {10,20,30,};
		int ar2[]= {40,50,60};
		int ar3[]= {70,80,90};
		
		
		System.out.println(Arrays.equals(ar1, ar2));
		System.out.println(Arrays.equals(ar1, ar3));

		System.out.println("hi");
		
		
		
		
		//Arrays.deepEquals(ar0, ar1);
		
		//use to compare 2 multi dimentional arrays
		
		
		
		
		
		
		
		
	}
}
