package Logical_program;

public class c1 {

}
