package Logical_program;

public class example4 
{

	public static void main(String[] args) {
		
		String org="abcd";
		String st="";
		
		
		for (int i=0;i<=org.length()-1;i++)
		{
			st=st+org.charAt(i);
		}
		
		System.out.println("orignal string:"+org);
		System.out.println("st string:"+st);
		
		
		
		
		
		
		
		
		
	}
	
}
