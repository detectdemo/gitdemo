package Logical_program;

public class Example13_Reverse_middle_String 
{

	public static void main(String[] args) {
		
		String str ="abc xyz abc1 xyz1";
		String[] ar=str.split(" ");  //[abc(0) xyz(1) abc1(2) xyz1(3)]
		
		for(int i=0; i<=ar.length-1; i++)
		{
			if(i%2==0)
			{
				String s1=ar[i];
				ar[i]=reversestring(s1);
			}
			
		}
		
		for (int i=0; i< ar.length;i++)
		{

			System.out.println(ar[i]+" ");
		}

			
		
	}
	
	public static String reversestring(String inp)
	{
		String rev = " ";
		
		
		for(int i=inp.length()-1;i>0;i--)
		{
			rev=rev + inp.charAt(i);
			
			
		}
		return rev;
		
		
		
		
		
		
		
		
		
		
		
	}
}
