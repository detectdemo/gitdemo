package Logical_program;

import java.util.Scanner;

public class Exampl6_even_odd
{
	public static void main(String[] args) {
		
		
		Scanner scan=new Scanner(System.in);
		System.out.println("enter no :");
		
		int num= scan.nextInt();
		
		if(num %2==0)
		{
			System.out.println("given num is even");
		}
		else
		{
			System.out.println("given num is odd");
		}
		
		
		
		
		
		
		
	}

}
