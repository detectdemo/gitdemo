package prctice;

import java.util.Scanner;

public class exp1
{

	public static void main(String[] args) {

	     int [] ar={561,654,544,5,456,};
	     int max=ar[0];
	     
	     for(int i=0;i<=ar.length-1;i++)
	     {
	         if(ar[i]>max)
	         {
	           max=ar[i];
	         }
	     }
	     System.out.println(max);
	}
}
