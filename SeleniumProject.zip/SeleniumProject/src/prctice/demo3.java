package prctice;

import java.util.Arrays;

public class demo3 {
	public static void main(String[] args) {
		
		int[]ar= {52,62,84,65,21};

        Arrays.sort(ar);
        
        for(int i=0;i<=ar.length-1;i++)
        {
        
        	System.out.println(ar[i]);
        }
        
		
		
		
		
		
		
		
	}

}
