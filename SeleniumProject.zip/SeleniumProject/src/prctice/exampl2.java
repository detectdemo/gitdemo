package prctice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class exampl2
{


	@Test
	public void TC10() throws InterruptedException
	{

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe");
	
		WebDriver driver=new ChromeDriver();
		//driver.manage().window().maximize();
		driver.get("https://www.flipkart.com/");
	
		Thread.sleep(2000);
	
		driver.close();
	



	}

}
