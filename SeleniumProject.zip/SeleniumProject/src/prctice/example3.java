package prctice;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class example3 
{


	@Test
	public void TC3()
	{
		Reporter.log("TC3 running... ",true);
	}
}
