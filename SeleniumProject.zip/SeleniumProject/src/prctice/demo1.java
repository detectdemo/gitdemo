 package prctice;

public class demo1 {
	
	public static void main(String[] args) {
		
		
		for(int i=1;i<=4;i=1)
		{
			System.out.println(i);
		}
		
		
		
		
		
		
	}

}
