package prctice;

import java.util.Scanner;

public class demo5 
{

	public static void main(String[] args) {
		
		Scanner scan =new Scanner(System.in);
		
		int ob= scan.nextInt();
		
		if(ob/2==0)
		{
			System.out.println("even");
		}
		else
		{
			System.out.println("odd");
		}
		 
		
		
		
	}
}
