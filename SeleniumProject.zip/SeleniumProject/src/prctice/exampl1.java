package prctice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class exampl1


{

	@Test
	public void TC1() throws InterruptedException
	{

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe");
	
		WebDriver driver=new ChromeDriver();
		//driver.manage().window().maximize();
		driver.get("https://www.facebook.com/?nocaa=1");
		
		Thread.sleep(2000);
		driver.close();
	}

	@Test
	public void TC2() throws InterruptedException
	{

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe");
	
		WebDriver driver=new ChromeDriver();
		//driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
	
		Thread.sleep(2000);
	
		driver.close();
	



	}
}
