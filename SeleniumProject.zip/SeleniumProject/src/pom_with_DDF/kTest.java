package pom_with_DDF;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class kTest 
{


	public static void main(String[] args) throws EncryptedDocumentException, IOException {
		
		FileInputStream file=new FileInputStream("C:\\Users\\vijay\\selenium\\July21B.xlsx");
		Sheet sh = WorkbookFactory.create(file).getSheet("DDF");
		
		
System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32 (2)\\chromedriver.exe" );
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("https://kite.zerodha.com/");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		klog1 log1=new klog1(driver);
		String UNinfo = sh.getRow(0).getCell(0).getStringCellValue();
		
		log1.inpklog1UN(UNinfo);
		String PSWinfo = sh.getRow(0).getCell(1).getStringCellValue();

		log1.inpklog1PSW(PSWinfo);
		
		log1.inpklog1LOginBtn();
		
		
		klog2 log2=new klog2(driver);
		String PINinfo = sh.getRow(0).getCell(2).getStringCellValue();

		log2.inpklog2PIN(PINinfo);
		log2.inpklog2Contbtn();
		
		khome log3=new khome(driver);
		String UNverifyuid = sh.getRow(0).getCell(3).getStringCellValue();

		log3.inpkhomeVERIFYUID(UNverifyuid);
		
		
		
		
		
		
		
		
	}
}
