package pom_with_DDF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class klog2 
{

	
	
	@FindBy(xpath="//input[@placeholder=\"PIN\"]")private WebElement PIN;
	@FindBy(xpath="//button[text()=\"Continue \"]")WebElement COntBtn;
	
	
	public klog2(WebDriver driver)

	{
		PageFactory.initElements(driver, this);
	}
	
	public void inpklog2PIN(String PININFO)
	{
		PIN.sendKeys(PININFO);
	}
	public void inpklog2Contbtn()
	{
		PIN.click();
	}
}
