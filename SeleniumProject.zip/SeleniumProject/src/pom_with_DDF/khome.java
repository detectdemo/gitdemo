package pom_with_DDF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class khome 
{

      @FindBy(xpath="//span[@class=\\\"user-id\\\"]") private	WebElement VERIFYUID;

      public khome(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}



      public void inpkhomeVERIFYUID(String uNverifyuid)
      {
    	String act = VERIFYUID.getText();
    	  String Exp="DV1510";
    	  if(act.equals(Exp))
    	  {
    		  System.out.println("pass");
    	  }
    	  else
    	  {
    		  System.out.println("fail");
    	  }
      }










	
}
