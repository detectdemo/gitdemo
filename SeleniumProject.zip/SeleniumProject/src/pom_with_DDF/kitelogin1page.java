package pom_with_DDF;

import java.security.PrivateKey;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class kitelogin1page 
{
		 //step1:declaration
	   @FindBy(xpath="//input[@type=\"text\"]")  private WebElement UN;//private WebElement UN-drivar.findElemenet(By.xpath(""));
	   @FindBy(xpath="//input[@type=\"password\"]")  private WebElement PSW;
	   @FindBy(xpath="//button[@type=\"submit\"]") private WebElement LoginBtn;
		 
	    //step2:initilazation
	public	 kitelogin1page(WebDriver driver)
		 {
			 PageFactory.initElements(driver, this);
		 }
		 
		 
		 //step3:usages
		 
		 public void inpkitelogin1pageUsername(String un)
		 {
			 UN.sendKeys(un);
		 }
		 
		 public void inpkitelogin1pagePassword(String password)
		 {
			 PSW.sendKeys(password);
		 }
		 
		 
		 public void inpkitelogin1pageLoginBtn()
		 {
			 LoginBtn.click();
		 }
	 
}
