package pom_with_DDF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class kitelogin2page 
{
//step1:declaration
	@FindBy(xpath="//input[@placeholder=\"PIN\"]") private WebElement PIN;
	@FindBy(xpath="//button[text()=\"Continue \"]") private WebElement CntBtn;
	
	
	//step2:initilazation
	
	public kitelogin2page(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	

	//step3:usages
	
	public void inpkitelogin2pagePin(String pininfo)
	{
		PIN.sendKeys(pininfo);
	}
	
	public void inpkitelogin2pageCntBtn()
	{
		CntBtn.click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
