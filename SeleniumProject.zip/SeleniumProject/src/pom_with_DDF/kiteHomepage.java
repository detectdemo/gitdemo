package pom_with_DDF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class kiteHomepage
{
//step1:declaration
	@FindBy(xpath="//span[@class=\"user-id\"]") private WebElement userID;
	
	//step2:initilazation
	
	public kiteHomepage(WebDriver driver)
	{
		PageFactory.initElements(driver , this);
	}
	
	//Step3: usages
	
	public void verifykiteHomepageUserId(String expUserId)
	{
		String actuserid = userID.getText();
	//	String ecpuserID="expUserId";
		
		if(actuserid.equals(expUserId))
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}
		
	}
	
	
	
	
}
