package sampl1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demo1 {

	public static void main(String[] args) {
		
		//step 1: set path of chromedriver.exe file  
		//parameter 1: name of the Browser
		//parameter 2: path of the chromedriver.exe
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vijay\\selenium\\chromedriver_win32\\chromedriver.exe");
		
		//step 2: creat an object of chrome browser
		
		WebDriver  driver=new ChromeDriver();		
		
		
		
		
		
		
		
		
		
	}
}
