package sampl1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demo3 {

	public static void main(String[] args) {
		
	
		System.setProperty("webdrive.chrome.drive","C:\\Users\\vijay\\selenium\\chromedriver_win32\\chromedriver.exe");
	
		
       
		                     ChromeDriver driver =new ChromeDriver();
	}
}
