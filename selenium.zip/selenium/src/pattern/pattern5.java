package pattern;

public class pattern5 
{

	
	//****
	//***
	//** 
	//*
	
	
	
	
	

	public static void main(String[] args) {
		int star=4;
		//for row   4<=4 5
	for(int i=1;i<=4;i++)
	{
		//for column
		for(int j=1;j<=star;j++)
		{
			System.out.print("v"+" ");
		}
		System.out.println();
		star--; //5
	}
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
