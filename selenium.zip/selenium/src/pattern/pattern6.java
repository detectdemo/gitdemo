package pattern;

public class pattern6 {

}
