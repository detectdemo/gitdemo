package atribute;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class text3
{

	public static void main(String[] args) {
		

		System.setProperty("webdriver.chrome.driver","C:\\Users\\vijay\\selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://m.facebook.com/");
		//create new a\c
		//driver.findElement(By.xpath("//a[text()='नवीन खाते तयार करा']")).click();

		//forget passwoerd
		driver.findElement(By.xpath("//a[text()='पासवर्ड विसरला?']")).click();
		
		
		
		
		
		
		
		
	}
}
