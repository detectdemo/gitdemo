package specifier;

public class samp1 {
	

}
