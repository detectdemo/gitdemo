package specifier;

public class samp2 {

	
	
	
	
	
	
	
	
}
