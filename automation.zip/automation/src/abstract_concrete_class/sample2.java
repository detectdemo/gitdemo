package abstract_concrete_class;
//abstract clas
//in complete class
abstract public class sample2 {
  
	
	//complete method
	
	public void m1()        //method declaration
	{
		System.out.println("method m1"); //method defination
	}
	
	
	
	//incomplete method

	abstract public void m2();  //method declaration
	
	//incomplete method

	abstract public void m3();   //method declaration

}
