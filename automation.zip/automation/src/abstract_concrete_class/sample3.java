package abstract_concrete_class;
//concrete class
public class sample3 extends sample2
{

	
	
	
	
	
	//complete method

	
	public void m2()
	{
		System.out.println("method complete in concrete class");
	}
	//complete method

	public void m3() {
		System.out.println("method complete in concrete class" );
		
	}
	

	//complete method
	
//	public void m1()        //method declaration
//	{
//		System.out.println("method m1"); //method defination
//	}
	
}
