package abstract_concrete_class;

//complete class
public class sampl1 {
	
	
	// complete method
	
	public void m1()    //method declaration
	{
		System.out.println("method m1"); //method defination
	}
	
	public void m2()   //method declaration 
	{
		System.out.println("method m2");    //method defination
	}

}
