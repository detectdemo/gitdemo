package abstract_concrete_class;

public class testsample {
	
	public static void main(String[] args) {
		
		sample3 s3=new sample3();
		s3.m1();
		s3.m2();
		s3.m3();
		
		
	}

}
