package abstract_concrete_class;

public class test_sample  
{

	
	public static void main(String[] args) {
		
		sapmle2() s1=new sample2();
		
		
		
	}
	
}
