package String;

public class sample3 {
public static void main(String[] args) {
	
	String s1="velocity";  //0 to 7
	String s2="";
	String s3="ABC";
	
	System.out.println(s1.length()); //8
	System.out.println(s1.isEmpty());//false
	System.out.println(s2.isEmpty()); //true
	System.out.println(s1.toUpperCase());//VELOCITY
	System.out.println(s1.toLowerCase());//velocity
	System.out.println(s3.toLowerCase()); //abc
//	System.out.println(s3);               //ABC

	
//	System.out.println(s1);

//	s1=s1.toUpperCase();
//	System.out.println(s1);
	
	
}	
}
