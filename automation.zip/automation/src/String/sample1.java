package String;

public class sample1 {
	
	public static void main(String[] args) {
		
		
		String s1="abc";
	    s1=s1+"de";
		     

     System.out.println(s1);
		      
		
	}

}
