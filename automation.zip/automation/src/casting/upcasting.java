package casting;

public class upcasting {
	
	
	public static void main(String[] args) {
//son s1 = new son();
//s1.mobile();
//s1.home();
//s1.money();
//s1.car();
		
	
		father f = new son();
		 f.car();
		 f.home();
		 f.money();
		 
		 
		
		
		
		
	}

}
