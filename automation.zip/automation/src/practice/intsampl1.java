package practice;

public interface intsampl1 {
	//100%incomplete method

	int a=20;
	void m1();
	void m2();
	
	
}
