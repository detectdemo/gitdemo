package practice;
//abstract class
// in complete class
abstract public class sample1 {
	
	public void m1()
	{
		System.out.println("m1");
	}
	
	abstract public void m2();
	
	
	
	abstract public void m3();
	

}
