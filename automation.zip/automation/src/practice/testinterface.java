package practice;

public class testinterface {
	
	
	
	
	
	
			
			public static void main(String[] args) {
				
				
				impsample m1=new  impsample();
				m1.m1();
				m1.m2();
				System.out.println(m1.a);
				
				
				
				
				
			}

}
