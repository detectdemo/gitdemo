package practice;

public class impsample implements intsampl1
{
	
	public void m1()
	{
		System.out.println("method m1 complete in implementation calss");
	}
   
	
	public void m2()
	{
		System.out.println("method m2 complete in implementation calss");
	}
}
