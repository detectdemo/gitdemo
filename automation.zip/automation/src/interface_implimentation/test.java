package interface_implimentation;

public class test {
	
	
	void m1()    //default access speciier ---> in class
	{
		
	}
	
   
	public static void main(String[] args) {
		
 final  int a=10;  //initilazation
		System.out.println(a);
		
		   a=20;//re_initilazation
					System.out.println(a);
				
	}

}
