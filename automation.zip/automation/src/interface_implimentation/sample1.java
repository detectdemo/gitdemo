package interface_implimentation;
// sample---->interfacename-->super interface
public interface sample1 {
	
	
	
	
	// declare 100% incomplet method
	
	
	
	int a=10;  ////static final int a=10;
		
		
	void m1();   //abstract public  void m1();  
	
	 void m2();  //abstract public  void m2(); 
	
	

}
