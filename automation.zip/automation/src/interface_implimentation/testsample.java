package interface_implimentation;

public class testsample {
	
	public static void main(String[] args) {
		sample2 s1=new sample2();
		s1.m1();
		s1.m2();
		System.out.println(s1.a);
		
		
		
		
	}

}
