package interface_implimentation;

public interface I1 {

	
	void m1();
	
	void m2();
	

}
