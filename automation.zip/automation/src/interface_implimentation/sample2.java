package interface_implimentation;
// sample --->implementation class
public class sample2 implements sample1

{
	public void m1()
	{
		System.out.println("method m1 completed in impementation class");
	}
   public void m2()
   {
	   System.out.println("method m2 completed in impementation class");
   }
}










