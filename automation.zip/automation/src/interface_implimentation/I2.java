package interface_implimentation;

public interface I2 {

	
	void m3();
	
	
	void m4();
	
}
