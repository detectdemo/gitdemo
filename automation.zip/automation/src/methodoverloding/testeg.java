package methodoverloding;

public class testeg {

	
	
	public static void main(String[] args) {

		
		eg e1=new eg();
		e1.mul(20,20);
		e1.mul(20,40,70);
		

		
	}
}
