package methodoverloding;

public class eg {
	
	public void mul(int a,int b)
	{
		int t=a*b;
		System.out.println(t);
		
	}
	public void mul (int a,int b, int c)
	{
		int T=a*b*c;
		System.out.println(T);
	}

}
