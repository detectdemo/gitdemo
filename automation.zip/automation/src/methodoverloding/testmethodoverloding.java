package methodoverloding;

public class testmethodoverloding {
	
	
	public static void main(String[] args) {
		
		methodoverloding m1=new methodoverloding();
		      m1.addition(20,20);
		      m1.addition(10,20,40);
		      
		
		
	}

}
