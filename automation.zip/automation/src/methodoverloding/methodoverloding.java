package methodoverloding;

public class methodoverloding {
	
	
public void addition(int a,int b)    //2 int paramiter
{
	int c=a+b;
    System.out.println(c);
}

public void addition(int a, int b,int c)  //3 int paramiter
{
	int sum=a+b+c;
System.out.println(sum);
}

}
