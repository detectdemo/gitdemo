package methodoverlodandoverriding;

public class egfather {
	
	public void money()
	{
		System.out.println("money: 2lakh");
	}
	public void farm()
	{
		System.out.println("farm:5R");
	}

}
