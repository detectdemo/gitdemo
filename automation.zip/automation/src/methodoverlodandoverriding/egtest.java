package methodoverlodandoverriding;

public class egtest {
	public static void main(String[] args) {
		
		egson t1=new egson();
		t1.car();
		t1.farm();
				
		
		
	}

}
