package methodoverlodandoverriding;

public class egson extends egfather
{
	
	public void car()
	{
		System.out.println("money:2cr");
		
	}
   public void farm()
   {
	   System.out.println("farm: 50R");
   }
}
