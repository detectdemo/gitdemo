package methodoverlodandoverriding;

public class testmethodoverriding {
	
	
	public static void main(String[] args) {
		

		son s1=new son();
		s1.car();
		s1.money();
		s1.home();
		
}
}
