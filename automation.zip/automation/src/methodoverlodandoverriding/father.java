package methodoverlodandoverriding;

public class father {
	
	
	public void money()
	{
		System.out.println("money; 1lakh");
		}
	public void car()
	{
		System.out.println("car ;honda city");
	}
	
	public void home()
	{
		System.out.println("home; 2bhk");
	}
	

}
