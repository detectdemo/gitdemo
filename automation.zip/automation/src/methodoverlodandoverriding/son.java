package methodoverlodandoverriding;

public class son   extends father
{

	//method overriding
	
	public void car()
	{
		System.out.println("car: kia seltos");
	}
	
	
	//method overriding

	public void money()
	{
		System.out.println("money: 1.5lakh");
	}
}
