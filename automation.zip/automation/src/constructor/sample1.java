package constructor;

public class sample1 {
	
	//default constructor---->provided by compiler
	//use to copy all the members of clas into object---->after object creation
//	sample1()
//	{
		
//	}
	
	public void addition()
	{
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
	}

}
