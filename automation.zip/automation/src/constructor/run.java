package constructor;

public class run {

	
	
	public static void main(String[] args) {
		
		usersamp2 u1=new usersamp2();
		u1.addition();
		u1.mul();
		
		usersampl u2=new usersampl();
		u2.addition();
		
		
		
	}
}
