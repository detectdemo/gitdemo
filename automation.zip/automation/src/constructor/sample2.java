package constructor;

public class sample2 {
	//default constructor---->provided by compiler
	//use to copy all the members of clas into object---->after object creation

//	sample2()
//	{
		
//	}
	
	
	public static void main(String[] args) {
		
		sample1 s1=new sample1();
		s1.addition();
		
		
		//sample--->classname--> data type
		//s1 -->object name-->to idintify object
		//new--->keyword--->  toto creat blank or empty object
		//sample()---->constructor
		
		
		
		
		
	}

}
