package constructor;

public class testparameter {
	
	public static void main(String[] args) {
		
		
		parameter p1=new parameter(20,20);
		p1.addition();
		
	}

}
