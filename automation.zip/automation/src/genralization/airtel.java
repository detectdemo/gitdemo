package genralization;
//implementation class 1
public class airtel    implements  simcard
{
	
   public void sms()
{
	System.out.println("sms:500");
}
	
	public void audiocalling()
	{
		System.out.println("audiocalling : 100");
	}
	 public void internet()
	 {
		 System.out.println("internetm : 1.5 gb");
	 }
	 public void newfeatureB()
	 {
	System.out.println("newfeature: B");	 
	 }

}
