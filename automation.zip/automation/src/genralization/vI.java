package genralization;
//implemention class 3

public class vI implements simcard
{
	
	
	  public void sms()
	  {
	  	System.out.println("sms:50");
	  }
	  	
	  	public void audiocalling()
	  	{
	  		System.out.println("audiocalling : 50");
	  	}
	  	 public void internet()
	  	 {
	  		 System.out.println("internetm : 3 gb");
	  	 }
	  	 public void newfeatureC()
	  	 {
	  	System.out.println("newfeature: C ");	 
	  	 }

}
