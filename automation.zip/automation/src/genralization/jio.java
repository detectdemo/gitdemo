package genralization;
//implemetation class 2
public class jio  implements simcard
{
	  public void sms()
	  {
	  	System.out.println("sms:1000");
	  }
	  	
	  	public void audiocalling()
	  	{
	  		System.out.println("audiocalling : 200");
	  	}
	  	 public void internet()
	  	 {
	  		 System.out.println("internetm : 2 gb");
	  	 }
	  	 public void newfeatureA()
	  	 {
	  	System.out.println("newfeature: A");	 
	  	 }

}
