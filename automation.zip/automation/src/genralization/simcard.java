package genralization;

public interface simcard 
{
	void sms();
	
	void audiocallin();
	 void internet();
	 

}
