package thisandsuper;

public class demo2 {
	
	int b=30;

}
