package ExceptionHandling;

public class sample6 {
public static void main(String[] args) {
	
	
	try
	{
		//risky code 1
	}
	
	catch(Exception a)
	{
		
	}
	
	try
	{
	    //risky code2	
	}
	catch(Exception e)
	{
		
	}
}
}
