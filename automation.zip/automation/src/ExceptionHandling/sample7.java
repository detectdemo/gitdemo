package ExceptionHandling;

public class sample7 {
	public static void main(String[] args) {
		
		
		try
		{
			//risky code1
			try
			{
				//risky code 2
			}
			catch(Exception a)
			{
				//todo handale Exception
			}
		}
		catch(Exception e)
		{
			
		}
	}

}
